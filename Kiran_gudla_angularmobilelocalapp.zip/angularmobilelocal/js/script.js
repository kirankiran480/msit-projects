/**
 * Created by Jarvis on 02-01-2016.
 */

angular.module('mobilelocal', ['ui.bootstrap','uiGmapgoogle-maps'])
    .config(function(uiGmapGoogleMapApiProvider) {
        uiGmapGoogleMapApiProvider.configure({
            //    key: 'your api key',
            v: '3.20', //defaults to latest 3.X anyhow
            libraries: 'places' // Required for SearchBox.
        });
    })
    .controller('TabsCtrl', function ($scope, $window, $http, $templateCache,$sce) {
        $scope.method = 'GET';
        $scope.url = '';

        $scope.location - "Hyderabad";

        $scope.map = {
            "center": {
                "latitude": 52.47491894326404,
                "longitude": -1.8684210293371217
            },
            "zoom": 8
        }; //TODO:  set location based on users current gps location
        $scope.marker = {
            id: 0,
            coords: {
                latitude: 52.47491894326404,
                longitude: -1.8684210293371217
            },
            options: { draggable: true },
            events: {
                dragend: function (marker, eventName, args) {

                    $scope.marker.options = {
                        draggable: true,
                        labelContent: "lat: " + $scope.marker.coords.latitude + ' ' + 'lon: ' + $scope.marker.coords.longitude,
                        labelAnchor: "100 0",
                        labelClass: "marker-labels"
                    };
                }
            }
        };
        var events = {
            places_changed: function (searchBox) {
                var place = searchBox.getPlaces();
                $scope.placename = place[0].name;

                console.log($scope.placename);
                if (!place || place == 'undefined' || place.length == 0) {
                    console.log('no place data :(');
                    return;
                }

                $scope.map = {
                    "center": {
                        "latitude": place[0].geometry.location.lat(),
                        "longitude": place[0].geometry.location.lng()
                    },
                    "zoom": 5
                };
                $scope.marker = {
                    id: 0,
                    coords: {
                        latitude: place[0].geometry.location.lat(),
                        longitude: place[0].geometry.location.lng()
                    }
                };
            }
        };
        $scope.searchbox = { template: 'searchbox.tpl.html', events: events };
        $scope.fetch = function() {
            $scope.code = null;
            $scope.response = null;

            $http({method: $scope.method, url: $scope.url, cache: $templateCache}).
            then(function(response) {
                $scope.status = response.status;
                $scope.data = response.data;
                console.log( $scope.data);
            }, function(response) {


                $scope.data = items || "Request failed";
                $scope.status = response.status;
            });
        };

        $scope.renderHtml = function(html_code)
        {
            return $sce.trustAsHtml(html_code);
        };
        $scope.updateModel = function(method, tabname) {
            $scope.placename =encodeURI($scope.placename);
            if(tabname=="news")
            {

                var url = "https://query.yahooapis.com/v1/public/yql?q=select%20title%20from%20rss%20where%20url%3D%22https%3A%2F%2Fnews.google.com%2Fnews%3Fgeo%3D"+$scope.placename+"%26output%3Drss%22&format=json&diagnostics=true&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys&callback=JSON_CALLBACK";

                $scope.method = method;
                $scope.url = url;
            }
            if(tabname=="weather") {
                var url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places%20where%20text%3D%22"+$scope.placename+"%2C%20ca%22)&format=json&diagnostics=true&callback=JSON_CALLBACK";

                $scope.method = method;
                $scope.url = url;
            }


        };

    });



