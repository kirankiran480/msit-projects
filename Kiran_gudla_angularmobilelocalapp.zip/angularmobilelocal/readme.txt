this is a psuedo application using angular
its called mobilelocal
it makes use of google maps api, yql rest api for fetching news and weather



author:
kiran gudla
kirankiran480@gmail.com
9494572893
7032646244