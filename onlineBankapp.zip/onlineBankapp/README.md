# onlineBankApplication
A Single page psuedo web app using Mean stack for registering Online bank application customers.

Installation :

unzip the file zip 
navigate to extracted directory using cmd
run 
npm update 
node server.js
and open localhost:3000 in browser 

screenshots are included in screenshots folder and online references are included in word files 

Thanks

Contact me :

kirankiran480@gmail.com
9494572893
7032646244
https://github.com/kirankiran480/onlineBankApplication.git