// Empty JS for your own code to be here

   
      $(document).ready(function(){
       // report();
          var availableTags = [];
        getItems();
        getHits();
      loadScript('http://maps.googleapis.com/maps/api/js?v=3&callback=initialize');

         var location=''; 
         var marker;
       //WWgeo();
        $(function() {
        	var json = JSON.parse(localStorage.getItem('itemData'));
            var availableTags =[];
    	$.each(json.parcels, function(idx, parcel){

				     availableTags.push(parcel.name);
				    
								    });
                      
 
		    $( "#itemSearch" ).autocomplete({
		      source: availableTags
		    });
  });


        $("#itemSearchSubmit").click(function()
        {
           var itemname = $("#itemSearch").val()
              getDetails(itemname);
        }

        	)
       
      });
      

      function sortby(prop)
      {
          
           var json = JSON.parse(localStorage.getItem('itemData'));
            var sorted = json.parcels.sort(function(a, b) {
        var x = a[prop]; var y = b[prop];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });

          console.log(sorted);

              var count = 1;
              $("#itemsList").html("");

				    $.each(sorted, function(idx, parcel){

				      var item = '<div class="panel panel-default">'+
											'<div class="panel-heading">'+
												 '<a class="panel-title collapsed" data-toggle="collapse" data-parent="itemsList" onclick="getDetails('+"'"+parcel.name+"'"+')" href="#panel'+count+'">'+parcel.name+'</a>'+
											'</div>'+
											'<div id="panel'+count+'" class="panel-collapse collapse">'+
												'<div class="panel-body">'+
													'&#8377 ' +parcel.price+
												'</div>'+
											'</div>'+
										'</div>';

				     var html = $("#itemsList").html();
				     html = html + item;
				       $("#itemsList").html(html);
				       count++;	
								    })
                      

      }
    function getDetails(Itemname)
    {
    	
    	var json = JSON.parse(localStorage.getItem('itemData'));

    	$.each(json.parcels, function(idx, parcel){

				     if(parcel.name == Itemname)
				     {
					
					          $("#Details").html("");
                              var parentDiv = document.createElement('div');
                              parentDiv.setAttribute("class","col-md-2 column productbox");
                              var imgelement = document.createElement('img');
                              imgelement.setAttribute("class","img-responsive");
                              imgelement.src = parcel.image;
                              var producttitle = document.createElement('div');
                              producttitle.setAttribute("class","producttitle");
                              producttitle.innerHTML = parcel.name;
                              var productprice = document.createElement('productprice');
                              productprice.setAttribute("class","productprice"); 
                              productprice.innerHTML = parcel.price;
                             parentDiv.appendChild(imgelement);
                             parentDiv.appendChild(producttitle);
                             parentDiv.appendChild(productprice);

                             $("#Details").append(parentDiv);
                           
                             setlocation(parcel.live_location.latitude,parcel.live_location.longitude);
                             

                  
				     }
								    });
                      
        
    }

 function  getHits() {
       	// body...

            //var url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places%20where%20text%3D%22"+val[0]+"%2C%20ca%22)&format=json&diagnostics=true&callback=handler";
                var url = "https://zoomcar-ui.0x10.info/api/courier?type=json&query=api_hits";
                

				$.ajax({
				   type: 'GET',
				    url: url,
				    async: false,
				    contentType: "application/json",
				    success: function(json) {
				        var json = $.parseJSON(json);
							       console.log(json.api_hits);
							  

							        var hits = json.api_hits;

							        $("#hits").html(hits);
							   
				                     
				            },
				    error: function(e) {
				       console.log(e.message);
				    }
				});

       }      


function getItems()
            {
                               
                 //var url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places%20where%20text%3D%22"+val[0]+"%2C%20ca%22)&format=json&diagnostics=true&callback=handler";
                var url = "https://zoomcar-ui.0x10.info/api/courier?type=json&query=list_parcel";

                 var dataToStore = "";
			

				$.ajax({
				   type: 'GET',
				    url: url,
				    async: false,
				    contentType: "application/json",
				    success: function(json) {

				    	localStorage.setItem('itemData', json);

				       var json = $.parseJSON(json);
				       console.log(json.parcels.length);
				       var totalItems = json.parcels.length;

				        var count = 1;

				    $.each(json.parcels, function(idx, parcel){

				      var item = '<div class="panel panel-default">'+
											'<div class="panel-heading">'+
												 '<a class="panel-title collapsed" data-toggle="collapse" data-parent="itemsList" onclick="getDetails('+"'"+parcel.name+"'"+')" href="#panel'+count+'">'+parcel.name+'</a>'+
											'</div>'+
											'<div id="panel'+count+'" class="panel-collapse collapse">'+
												'<div class="panel-body">'+
													'&#8377 ' +parcel.price+
												'</div>'+
											'</div>'+
										'</div>';

				     var html = $("#itemsList").html();
				     html = html + item;
				       $("#itemsList").html(html);
				       count++;	
								    })
                      
                     
							       $("#totalItems").html(totalItems);

				},
								    error: function(e) {
								       console.log(e.message);
								    }
								});
              // var element = document.createElement("script");
              // element.setAttribute("src",url);
              // document.getElementsByTagName("head")[0].appendChild(element);
            
    }
    
     
             
         

          function loadScript(src){
  
    var script = document.createElement("script");
    script.type = "text/javascript";
    
    document.getElementsByTagName("head")[0].appendChild(script);
    script.src = src;
  }
  
  
function setlocation(latitude,longitude)
{

    var mapOptions = {
          zoom: 8,
          center: new google.maps.LatLng(latitude, longitude),
          mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById('map_canvas'),mapOptions);
  }




function initialize() {
    
    var mapOptions = {
          zoom: 8,
          center: new google.maps.LatLng(-34.397, 150.644),
          mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    map = new google.maps.Map(document.getElementById('map_canvas'),
            mapOptions);
  }

