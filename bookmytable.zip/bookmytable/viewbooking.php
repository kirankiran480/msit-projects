<?php
session_start();

?>

<html>
<head>
</head>

<body>
<a href="logout.php">LOGOUT</a>
  <?php 
if(isset($_SESSION["username"]) )
{

     $user = $_SESSION["username"];
     $conn = new MongoClient('localhost');
     $db = $conn->u1144632;
     $collection = $db->bookings;
     $cursor = $collection->find();
       echo <<<EOT
        <table>
  <tr>
  <th>User</th>
  <th>Date</th>
  <th>From</th>
  <th>To</th>
  </tr>
EOT;
  

foreach ($cursor as $doc) {
    
  
    // do something to each document
    
    

      $user =  $doc['user'];
      $date =  $doc['date'];
      $from =  $doc['from'];
      $to = $doc['to'];
        echo <<<EOT
          <tr>
          <td>
              $user         
          </td>
          <td>
              $date
          </td>
          <td>
          $from
          </td>
          <td>
          $to
          </td>
          </tr>

EOT;



}
       echo <<<EOT
           </table>
EOT;


 

}
 ?>
</body>
</html>
       







