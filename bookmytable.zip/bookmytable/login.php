 <?php 

if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
if(isset($_SESSION['user']))
{
   header("Location: index.php");
  
   exit;
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="utf-8">
		<title>bookmytable</title>
		
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<!--[if lt IE 9]>
			<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<link href="css/styles.css" rel="stylesheet">
	</head>
	<body>


  

    
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h1 class="text-center">Login</h1>
   
      <div class="modal-body">
          <form class="form col-md-12 center-block" method="post">
            <div class="form-group">
              <input type="text" name="username" class="form-control input-lg" placeholder="Username">
            </div>
            <div class="form-group">
              <input type="password" name="password" class="form-control input-lg" placeholder="Password">
            </div>
            <div class="form-group">
                <input class="btn btn-primary btn-lg btn-block" type="submit" name="login" value="login"/>
            
              <span class="pull-right"><a href="#">Register</a></span><span><a href="#">Need help?</a></span>
            </div>
          </form>
      </div>
    
  
  

	
	</body>
</html>

<?php // rnlogin.php
$error = $user = $pass = "";
function sanitize($var)
{
 $var = stripslashes($var);
 $var = htmlentities($var);
 $var = strip_tags($var);
 return $var;
}
if (isset($_POST['username']))
{
 $user = sanitize($_POST['username']);
 $pass = sanitize($_POST['password']);

   $conn = new MongoClient('localhost');
            $db = $conn->u1144632;
                     
             $collection = $db->createCollection("users");
   echo "Collection created succsessfully";
   $collection = $db->users;
  $token = md5($pass); 
if ($user == "" || $token == "")
 {
 $error = "Empty<br />";
 }
 else
 {
 $qry = array("username" => $user,"password" => md5($pass));
$result = $collection->findOne($qry);

if($result){
// Rest of code up to you.... 

 $_SESSION['username'] = $user;

echo "<a href='index.php' >Login succsessfully press here</a>";
 
} 

}
}