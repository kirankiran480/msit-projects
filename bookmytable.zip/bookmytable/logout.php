<?php
if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}
unset($_SESSION);
session_destroy();

echo "logout Successfull";
echo  "<a href='login.php' >Please click here</a>";

?>