<?php

if (session_status() !== PHP_SESSION_ACTIVE) {session_start();}


if(isset($_SESSION["username"]) )
{

     $user = $_SESSION["username"];
     if($user=="admin1")
     {
       echo "<a href='viewbooking.php'>View Bookings</a>";

     }
     $conn = new MongoClient('localhost');
     $db = $conn->u1144632;
     $db->createCollection("bookings");
     $collection = $db->bookings;
    
      if(isset($_REQUEST["Save"]))
        {
  
         $insert = array("user" => $_POST['bookingname'],"seats" =>$_POST['seatsrequired'], "from" => $_POST['from'] , "to" => $_POST['to'],"date" =>$_POST['bookingdate']);
                 $collection->insert($insert);
                 echo "Booking successfull!!";
        }


  }

  else {
    header("Location : index.php");
    exit;
  }
        
        
        ?>

</head>

<body>
  
   <a href="logout.php">LOGOUT</a>
   <form action="" name="bookingform" method="post">
      booking name:<input type="text" name="bookingname">
        Seats :<input type="number" name="seatsrequired" ><br/>
           date :<input type="date" name="bookingdate" value=""><br>
           from :<input type="time" name="from" value=""><br>
           to:<input type="time" name="to" value=""><br>

        <input type="submit" name="Save"  value="Save"/>
            
        </form>
</body>
</html>
       