// Empty JS for your own code to be here

   
      $(document).ready(function(){
       // report();
          var availableTags = [];
        getItems();
        getHits();

             $(function() {
          var json = JSON.parse(localStorage.getItem('itemData'));
            var availableTags =[];
      $.each(json.problems, function(idx, problem){

             availableTags.push(problem.name);
            
                    });
                      
 
        $( "#problemSearch" ).autocomplete({
          source: availableTags
        });
  });


        $("#problemSearchSubmit").click(function()
        {
           var itemname = $("#problemSearch").val()
              getDetails(itemname);
        }

          )
  
});
      function  getHits() {
        // body...

            //var url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places%20where%20text%3D%22"+val[0]+"%2C%20ca%22)&format=json&diagnostics=true&callback=handler";
                var url = "https://hackerearth.0x10.info/api/problems?type=json&query=api_hits";
                

        $.ajax({
           type: 'GET',
            url: url,
            async: false,
            contentType: "application/json",
            success: function(json) {
                var json = $.parseJSON(json);
                     console.log(json.api_hits);
                

                      var hits = json.api_hits;

                      $("#hits").html(hits);
                 
                             
                    },
            error: function(e) {
               console.log(e.message);
            }
        });

       }      

      function getDetails(problemname)
      {
        var json = JSON.parse(localStorage.getItem('itemData'));

      $.each(json.problems, function(idx, problem){

             if(problem.name == problemname)
             {
          
                    $("#problemGrid").html("");
                              
                       var nullflag = 0;
                  $.each(problem, function(key, value){
    if (value === "" || value === null){
        problem[key] = "No itemfound"
        nullflag = 1;
    }
});
                if(nullflag == 0){
                  var likeno = 0;
                  likeno = localStorage.getItem(problem.name);
                  if(likeno == null)
                  {
                    likeno = 0;
                  }
                            
                  var item = '<div class="clearfix col-md-12 thumbnail">'+
          '<div class="row">'+
            '<div class="col-md-4">'+  
            '<img width="100" height="100" alt = "No image loaded" src="'+problem.image+'" class="img-thumbnail">'+
            '</div>'+
            '<div class="col-md-8">'+
               '<div class="row">'+
                '<div class="col-md-12">'+
              '<div>'+problem.name+'</div>'+
              '</div></div>'+
               '<div class="row">'+
                 '<div class="col-md-6">'+
              '<div>Solved by:'+problem.solved_by+'</div>'+
              '</div>'+
              '<div class="col-md-6">'+
              '<div>'+
                'rating: '+problem.rating+
              '</div>'+
              '</div>'+
              '</div>'+
               '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div>'+
                problem.parent_challenge+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div class="tags">'+
                'tags: '+ problem.tags.toString()+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-8">'+
                  '<a href="'+problem.url+'" target="_blank" >link</a>'+
                 '</div>'+
                 '<div class="col-md-4">'+
                 '<div>'+
                 '<span class="glyphicon glyphicon-thumbs-up likes" onclick="likescounter(\''+problem.name+'\',this)" aria-hidden="true">'+likeno+'</span>'+
                  '</div>'+
              '</div>'+
              '</div>'+
            '</div>'+
         '</div>'+
        '</div>';
            

             
            var html = $("#problemGrid").html();
             html = html + item;
               $("#problemGrid").html(html);
               count++; 

                }        
                  
             }
                    });
      }
      function likescounter(problemname,element)
      {
        
        
           if(!localStorage.getItem(problemname))
           {
               localStorage.setItem(problemname, 1);  
                element.innerHTML = 1;
           }
           else
           {
              var count =  localStorage.getItem(problemname);
              count =  parseInt(count);
              count++;
              localStorage.setItem(problemname,count);
              element.innerHTML = count;
           }
          
  
      }

function getItems()
            {
                               
                 //var url = "http://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places%20where%20text%3D%22"+val[0]+"%2C%20ca%22)&format=json&diagnostics=true&callback=handler";
                var url = "https://hackerearth.0x10.info/api/problems?type=json&query=list_problems";
    $.ajax({
				   type: 'GET',
				    url: url,
				    async: false,
				    contentType: "application/json",
				    success: function(json) {

				    	localStorage.setItem('itemData', json);

                console.log(json);
				       json = JSON.parse(json);

				       var totalItems = json.problems.length;
    
				        var count = 1;

				    $.each(json.problems, function(idx, problem){
                  var nullflag = 0;
                  $.each(problem, function(key, value){
    if (value === "" || value === null){
        problem[key] = "No itemfound"
        nullflag = 1;
    }
});
                if(nullflag == 0){
                  var likeno = 0;
                  likeno = localStorage.getItem(problem.name);
                  if(likeno == null)
                  {
                    likeno = 0;
                  }
                            
                  var item = '<div class="clearfix col-md-12 thumbnail">'+
          '<div class="row">'+
            '<div class="col-md-4">'+  
            '<img width="100" height="100" alt = "No image loaded" src="'+problem.image+'" class="img-thumbnail">'+
            '</div>'+
            '<div class="col-md-8">'+
               '<div class="row">'+
                '<div class="col-md-12">'+
              '<div>'+problem.name+'</div>'+
              '</div></div>'+
               '<div class="row">'+
                 '<div class="col-md-6">'+
              '<div>Solved by:'+problem.solved_by+'</div>'+
              '</div>'+
              '<div class="col-md-6">'+
              '<div>'+
                'rating: '+problem.rating+
              '</div>'+
              '</div>'+
              '</div>'+
               '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div>'+
                problem.parent_challenge+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div class="tags">'+
                'tags: '+ problem.tags.toString()+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-8">'+
                  '<a href="'+problem.url+'" target="_blank" >link</a>'+
                 '</div>'+
                 '<div class="col-md-4">'+
                 '<div>'+
                 '<span class="glyphicon glyphicon-thumbs-up likes" onclick="likescounter(\''+problem.name+'\',this)" aria-hidden="true">'+likeno+'</span>'+
                  '</div>'+
              '</div>'+
              '</div>'+
            '</div>'+
         '</div>'+
        '</div>';
            

             
            var html = $("#problemGrid").html();
             html = html + item;
               $("#problemGrid").html(html);
               count++; 

                }
                  
								    })
                      
                    $("#totalItems").html(totalItems);

				},
								    error: function(e) {
								       console.log(e.message);
								    }
								});
              // var element = document.createElement("script");
              // element.setAttribute("src",url);
              // document.getElementsByTagName("head")[0].appendChild(element);
            
    }
    
     
             
          function sortby(prop)
      {
          
           var json = JSON.parse(localStorage.getItem('itemData'));

            var sorted = json.problems.sort(function(a, b) {
        var x = a[prop]; var y = b[prop];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });

          console.log(sorted);

              var count = 1;
              $("#problemGrid").html("");

            $.each(sorted, function(idx, problem){
           
               var nullflag = 0;
                  $.each(problem, function(key, value){
    if (value === "" || value === null){
        problem[key] = "No itemfound"
        nullflag = 1;
    }
});
 if(nullflag == 0){   
             var likeno = 0;
                  likeno = localStorage.getItem(problem.name);
                  if(likeno == null)
                  {
                    likeno = 0;
                  }
           var item = '<div class="clearfix col-md-12 thumbnail">'+
          '<div class="row">'+
            '<div class="col-md-4">'+  
            '<img width="100" height="100" alt = "No image loaded" src="'+problem.image+'" class="img-thumbnail">'+
            '</div>'+
            '<div class="col-md-8">'+
               '<div class="row">'+
                '<div class="col-md-12">'+
              '<div>'+problem.name+'</div>'+
              '</div></div>'+
               '<div class="row">'+
                 '<div class="col-md-6">'+
              '<div>Solved by:'+problem.solved_by+'</div>'+
              '</div>'+
              '<div class="col-md-6">'+
              '<div>'+
                'rating: '+problem.rating+
              '</div>'+
              '</div>'+
              '</div>'+
               '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div>'+
                problem.parent_challenge+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-12">'+
              '<div class="tags">'+
                'tags: '+ problem.tags.toString()+
              '</div>'+
              '</div>'+
              '</div>'+
              '<div class="row">'+
                 '<div class="col-md-8">'+
                  '<a href="'+problem.url+'" target="_blank" >link</a>'+
                 '</div>'+
                 '<div class="col-md-4">'+
                 '<div>'+
                 '<span class="glyphicon glyphicon-thumbs-up likes" onclick="likescounter(\''+problem.name+'\',this)" aria-hidden="true">'+likeno+'</span>'+
                  '</div>'+
              '</div>'+
              '</div>'+
            '</div>'+
         '</div>'+
        '</div>';
            
             var html = $("#problemGrid").html();
             html = html + item;
               $("#problemGrid").html(html);
               count++; 
             }
                    })
                      

      }

      
  
  
